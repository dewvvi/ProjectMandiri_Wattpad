# RESTful API Manajemen Cerita Wattpad

Node.js + Express + MongoDB Atlas (Mongoose). Fitur: 5 endpoint CRUD, filtering, pagination (maksimal 100 data/halaman), sorting, projection, dan error handling terpusat.

## 1. Persiapan MongoDB Atlas
1. Di Atlas, buka **Database Access** dan buat database user (username/password). Ini bukan username/password login akun Atlas.
2. Buka **Network Access** dan tambahkan IP publik komputer yang dipakai. Untuk penggunaan lokal, pilih opsi tambah IP saat ini. Hindari `0.0.0.0/0` kecuali benar-benar memahami risikonya.
3. Buka cluster, klik **Connect > Drivers > Node.js**, lalu salin connection string `mongodb+srv://...`.
4. Ganti `<DB_USERNAME>`, `<DB_PASSWORD>`, dan `<CLUSTER_HOST>` pada connection string dengan nilai yang sesuai. Jika password mengandung karakter khusus, lakukan URL-encoding pada bagian password.
5. Database/collection tidak harus dibuat manual; MongoDB membuatnya saat data pertama dimasukkan.

## 2. Konfigurasi lokal
Di folder proyek, buat file `.env` dengan isi seperti berikut (gunakan nilai Atlas milik sendiri):

```env
MONGODB_URI=mongodb+srv://DB_USERNAME:DB_PASSWORD@CLUSTER_HOST/?retryWrites=true&w=majority
DB_NAME=wattpaddb
PORT=3000
```

Jangan menambahkan tanda kutip yang menjadi bagian literal nilai dan jangan membagikan file `.env`. Jangan mengunggah `.env` ke GitHub.

## 3. Jalankan aplikasi (PowerShell)
Buka terminal pada folder yang berisi `package.json`, lalu jalankan satu per satu:

```powershell
npm install
npm start
```

Jika berhasil, terminal menampilkan `Terhubung ke MongoDB Atlas` dan `Server berjalan di http://localhost:3000`. Biarkan terminal tetap berjalan.

Untuk mengisi 1.000 data contoh agar pagination/filter/sort bisa diuji, buka terminal kedua pada folder proyek lalu jalankan:

```powershell
npm run seed
```

Seed menghapus data yang sudah ada di collection cerita sebelum memasukkan data contoh. Jangan jalankan seed jika collection berisi data yang ingin dipertahankan. Jumlah data dapat ditentukan, misalnya `node scripts/seed.js 500`.

## 4. Endpoint
| Method | URL | Fungsi |
|---|---|---|
| GET | `/cerita` | Daftar cerita |
| GET | `/cerita/:id` | Detail cerita |
| POST | `/cerita` | Tambah cerita |
| PUT | `/cerita/:id` | Ubah cerita |
| DELETE | `/cerita/:id` | Hapus cerita |

Contoh query:
- `GET http://localhost:3000/cerita?genre=Romance`
- `GET http://localhost:3000/cerita?page=2&limit=20`
- `GET http://localhost:3000/cerita?sortBy=jumlahBab&order=desc`
- `GET http://localhost:3000/cerita?fields=judul,penulis`

Body JSON untuk POST:
```json
{
  "judul": "Senja di Kota",
  "penulis": "Dewi",
  "genre": "Romance",
  "sinopsis": "Dua orang bertemu di sebuah kota.",
  "status": "ongoing",
  "jumlahBab": 5
}
```

Catatan: `genre` harus salah satu dari Romance, Fantasy, Horror, Mystery, Action, Comedy, Drama. `status` adalah `ongoing` atau `completed`.
