// Middleware error handling TERPUSAT.
// Semua error dari route/controller (lewat next(err)) berakhir di sini,
// sehingga format response error selalu seragam.

const isProduction = process.env.NODE_ENV === "production";

module.exports = (err, req, res, next) => {
  // Jika response sudah terkirim, serahkan ke handler bawaan Express
  if (res.headersSent) return next(err);

  let statusCode = err.statusCode || err.status || 500;
  let message = err.message || "Terjadi kesalahan pada server";
  let errors;

  // JSON body tidak valid (dari express.json)
  if (err.type === "entity.parse.failed") {
    statusCode = 400;
    message = "Format JSON pada body request tidak valid";
  }

  // ID MongoDB tidak valid / tipe data tidak sesuai
  if (err.name === "CastError") {
    statusCode = 400;
    message =
      err.path === "_id"
        ? "Format ID cerita tidak valid"
        : `Nilai untuk field '${err.path}' tidak valid`;
  }

  // Validasi schema Mongoose: tampilkan detail per field
  if (err.name === "ValidationError" && err.errors) {
    statusCode = 400;
    message = "Validasi data gagal";
    errors = Object.values(err.errors).map((e) => ({
      field: e.path,
      message: e.message
    }));
  }

  // Nilai unik duplikat (jika ada unique index)
  if (err.code === 11000) {
    statusCode = 409;
    message = "Data dengan nilai unik tersebut sudah ada";
  }

  // Jangan bocorkan detail error internal ke client
  if (statusCode >= 500) {
    console.error(err);
    if (isProduction) message = "Terjadi kesalahan pada server";
  }

  const body = { success: false, statusCode, message };
  if (errors) body.errors = errors;
  if (!isProduction && statusCode >= 500) body.stack = err.stack;

  res.status(statusCode).json(body);
};
