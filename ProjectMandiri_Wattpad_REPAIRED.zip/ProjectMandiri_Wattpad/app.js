require("dotenv").config();

const express = require("express");
const mongoose = require("mongoose");

const ceritaRoutes = require("./routes/ceritaRoutes");
const errorHandler = require("./middleware/errorHandler");
const AppError = require("./utils/AppError");

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());

// Route cerita Wattpad
app.use("/cerita", ceritaRoutes);

// Endpoint tidak ditemukan -> diteruskan ke error handler terpusat
app.use((req, res, next) => {
  next(new AppError(`Endpoint ${req.method} ${req.originalUrl} tidak ditemukan`, 404));
});

// Error handler harus paling akhir
app.use(errorHandler);

// Export app agar mudah diuji; server hanya jalan jika file ini dieksekusi langsung
module.exports = app;

if (require.main === module) {
  if (!process.env.MONGODB_URI) {
    console.error("MONGODB_URI belum diatur. Salin .env.example menjadi .env lalu isi nilainya.");
    process.exit(1);
  }

  mongoose
    .connect(process.env.MONGODB_URI, {
      // Nama database dipakai jika tidak tertulis di URI
      dbName: process.env.DB_NAME || "wattpaddb"
    })
    .then(() => {
      console.log("Terhubung ke MongoDB Atlas");
      app.listen(PORT, () => {
        console.log(`Server berjalan di http://localhost:${PORT}`);
      });
    })
    .catch((err) => {
      console.error("Gagal terhubung ke MongoDB:", err.message);
      process.exit(1);
    });
}
