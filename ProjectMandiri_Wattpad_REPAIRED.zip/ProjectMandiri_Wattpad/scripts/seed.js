// Mengisi database dengan data contoh dalam jumlah besar
// agar fitur pagination, filtering, dan sorting bisa dicoba.
//
// Pemakaian:
//   npm run seed          -> 1000 data (default)
//   node scripts/seed.js 5000
require("dotenv").config();
const mongoose = require("mongoose");
const Cerita = require("../models/ceritaModel");
const { GENRES, STATUSES } = Cerita;

const total = Number(process.argv[2]) || 1000;

const kataDepan = ["Cinta", "Rahasia", "Senja", "Bayangan", "Langit", "Takdir", "Hujan", "Jejak", "Mimpi", "Luka", "Dendam", "Rindu", "Bintang", "Lorong", "Janji"];
const kataBelakang = ["di Ujung Waktu", "yang Hilang", "Terakhir", "Tanpa Nama", "Kota Tua", "Sang Penulis", "Dua Dunia", "Malam Itu", "Tak Berujung", "Pertama", "dalam Diam", "di Balik Cermin"];
const penulisList = ["dewi_putri", "arka_senja", "nadia.rahma", "bima_wirawan", "salsa_aurora", "raka_pratama", "mawar_hitam", "luna_malam", "fajar_story", "kirana_kata"];

const pick = (arr) => arr[Math.floor(Math.random() * arr.length)];

const buatData = (i) => {
  const genre = pick(GENRES);
  const status = pick(STATUSES);
  return {
    judul: `${pick(kataDepan)} ${pick(kataBelakang)} #${i + 1}`,
    penulis: pick(penulisList),
    genre,
    sinopsis: `Cerita ${genre.toLowerCase()} contoh nomor ${i + 1} untuk keperluan pengujian API.`,
    status,
    jumlahBab: status === "completed" ? 20 + Math.floor(Math.random() * 80) : Math.floor(Math.random() * 40),
    createdAt: new Date(Date.now() - Math.floor(Math.random() * 365 * 24 * 3600 * 1000))
  };
};

(async () => {
  try {
    await mongoose.connect(process.env.MONGODB_URI, {
      dbName: process.env.DB_NAME || "wattpaddb"
    });
    await Cerita.deleteMany({});
    const docs = Array.from({ length: total }, (_, i) => buatData(i));
    await Cerita.insertMany(docs);
    await Cerita.syncIndexes();
    console.log(`Berhasil menambahkan ${total} data cerita.`);
  } catch (err) {
    console.error("Seed gagal:", err.message);
    process.exitCode = 1;
  } finally {
    await mongoose.disconnect();
  }
})();
