// Error buatan sendiri agar controller cukup menulis:
//   throw new AppError("pesan", 400);
class AppError extends Error {
  constructor(message, statusCode = 500) {
    super(message);
    this.name = "AppError";
    this.statusCode = statusCode;
  }
}

module.exports = AppError;
